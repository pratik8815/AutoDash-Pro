#ifndef GEARWIDGET_H
#define GEARWIDGET_H

#include <QLabel>

class GearWidget : public QLabel
{
    Q_OBJECT
public:
    explicit GearWidget(QWidget *parent = nullptr);
    void setGear(int gear);
};

#endif // GEARWIDGET_H