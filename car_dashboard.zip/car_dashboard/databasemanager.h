#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H

#include <QSqlDatabase>
#include <QString>

class DatabaseManager
{
public:
    DatabaseManager();
    ~DatabaseManager();

    bool init(const QString &dbPath);
    void logData(int speed, int rpm, int gear, int fuel);

private:
    QSqlDatabase m_db;
    bool m_initialized = false;
};

#endif // DATABASEMANAGER_H