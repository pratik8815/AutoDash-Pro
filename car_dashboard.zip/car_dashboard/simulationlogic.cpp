#include "simulationlogic.h"
#include <QtGlobal>

namespace SimulationLogic {

int maxSpeedForGear(int gear)
{
    switch (gear)
    {
        case -1: return 20;
        case 0:  return 0;
        case 1:  return 32;
        case 2:  return 54;
        case 3:  return 80;
        case 4:  return 120;
        case 5:  return 220;
        default: return 0;
    }
}

int targetRpmForGear(int gear, int targetSpeed)
{
    int targetRpm;
    if (gear == 0)
    {
        targetRpm = 800;
    }
    else if (gear == -1)
    {
        targetRpm = 800 + targetSpeed * 60;
    }
    else
    {
        int gearFactor = 6 - gear;
        targetRpm = 800 + targetSpeed * gearFactor * 25;
    }
    return qBound(800, targetRpm, 8000);
}

double easeToward(double current, double target, double easing)
{
    double next = current + (target - current) * easing;
    if (qAbs(target - next) < 0.3)
    {
        next = target;
    }
    return next;
}

} // namespace SimulationLogic