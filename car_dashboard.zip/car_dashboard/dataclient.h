#ifndef DATACLIENT_H
#define DATACLIENT_H

#include <QObject>
#include <QTcpSocket>

class DataClient : public QObject
{
    Q_OBJECT
public:
    explicit DataClient(QObject *parent = nullptr);
    void connectToServer(const QString &host, quint16 port);
    static bool parseLine(const QByteArray &line, int &speed, int &rpm, int &gear, int &fuel);

signals:
    void dataReceived(int speed, int rpm, int gear, int fuel);
    void connectionStatusChanged(bool connected);

private slots:
    void onReadyRead();
    void onConnected();
    void onDisconnected();

private:
    QTcpSocket *m_socket;
    QByteArray m_buffer;
};

#endif // DATACLIENT_H