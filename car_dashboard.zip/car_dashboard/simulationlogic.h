// #ifndef SIMULATIONLOGIC_H
// #define SIMULATIONLOGIC_H

// class simulationlogic
// {
// public:
//     simulationlogic();
// };

//#endif // SIMULATIONLOGIC_H
#ifndef SIMULATIONLOGIC_H
#define SIMULATIONLOGIC_H

// Pure, Qt-widget-free logic pulled out of MainWindow so it can be
// unit tested directly (no QApplication, no timers, no UI needed).
namespace SimulationLogic
{

// Same table MainWindow::maxSpeedForGear used to own.
int maxSpeedForGear(int gear);

// Same target-RPM formula from MainWindow::tickSimulation().
int targetRpmForGear(int gear, int targetSpeed);

// Same easing/snap formula used for m_displaySpeed / m_displayRpm.
double easeToward(double current, double target, double easing);

} // namespace SimulationLogic

#endif // SIMULATIONLOGIC_H
