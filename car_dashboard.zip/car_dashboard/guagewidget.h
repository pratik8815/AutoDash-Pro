#ifndef GUAGEWIDGET_H
#define GUAGEWIDGET_H

#include <QWidget>

class GuageWidget : public QWidget
{
    Q_OBJECT
public:
    explicit GuageWidget(QWidget *parent = nullptr);

    void setRange(int minValue, int maxValue);
    void setTitle(const QString &title);
    void setUnit(const QString &unit);
    void setValue(int value);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QString m_title;
    QString m_unit;
    int m_minValue = 0;
    int m_maxValue = 100;
    int m_value = 0;

signals:
};

#endif // GUAGEWIDGET_H
