#include "gearwidget.h"

GearWidget::GearWidget(QWidget *parent) : QLabel(parent)
{
    setAlignment(Qt::AlignCenter);
    setMinimumSize(70, 200);
    setGear(0);
}

void GearWidget::setGear(int gear)
{
    QString display;
    if (gear < 0)
    {
        display = "R";
    }
    else if (gear == 0)
    {
        display = "N";
    }
    else
    {
        display = QString::number(gear);
    }
    setText(display);
    setStyleSheet(
        "QLabel {"
        "  color: white;"
        "  font-size: 48px;"
        "  font-weight: bold;"
        "  background-color: #0d0d0d;"
        "  border: 2px solid #333;"
        "  border-radius: 12px;"
        "}"
        );
}