#include "gaugewidget.h"
#include <QPainter>
#include <QPainterPath>
#include <QtMath>

GaugeWidget::GaugeWidget(QWidget *parent) : QWidget(parent)
{
    setMinimumSize(200, 200);
}

void GaugeWidget::setRange(int minValue, int maxValue)
{
    m_minValue = minValue;
    m_maxValue = maxValue;
    update();
}

void GaugeWidget::setTitle(const QString &title)
{
    m_title = title;
    update();
}

void GaugeWidget::setUnit(const QString &unit)
{
    m_unit = unit;
    update();
}

void GaugeWidget::setValue(int value)
{
    m_value = qBound(m_minValue, value, m_maxValue);
    update();
}

void GaugeWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    int side = qMin(width(), height());
    painter.translate(width() / 2, height() / 2);
    painter.scale(side / 220.0, side / 220.0);

    // --- Outer glow/bezel (radial gradient, recessed glass look) ---
    QRadialGradient bezelGradient(0, 0, 115);
    bezelGradient.setColorAt(0.0, QColor(35, 35, 35));
    bezelGradient.setColorAt(0.7, QColor(15, 15, 15));
    bezelGradient.setColorAt(1.0, QColor(0, 0, 0));
    painter.setPen(Qt::NoPen);
    painter.setBrush(bezelGradient);
    painter.drawEllipse(QPoint(0, 0), 115, 115);

    // --- Inner dial face ---
    painter.setPen(QPen(QColor(60, 60, 60), 2));
    painter.setBrush(QColor(8, 8, 8));
    painter.drawEllipse(QPoint(0, 0), 100, 100);

    int startAngle = 225;
    int sweepAngle = -270;

    double fraction = (m_maxValue > m_minValue)
                          ? double(m_value - m_minValue) / (m_maxValue - m_minValue)
                          : 0.0;

    // --- Background arc track ---
    QRectF arcRect(-90, -90, 180, 180);
    painter.setPen(QPen(QColor(40, 40, 40), 8, Qt::SolidLine, Qt::RoundCap));
    painter.drawArc(arcRect, startAngle * 16, sweepAngle * 16);

    // --- Colored progress arc ---
    QColor progressColor = (fraction > 0.85) ? QColor(220, 50, 50) : QColor(0, 200, 210);
    painter.setPen(QPen(progressColor, 8, Qt::SolidLine, Qt::RoundCap));
    painter.drawArc(arcRect, startAngle * 16, int(sweepAngle * fraction * 16));

    // --- Tick marks ---
    painter.setPen(QPen(QColor(150, 150, 150), 1));
    int steps = 10;
    for (int i = 0; i <= steps; ++i) {
        double angle = qDegreesToRadians(startAngle + sweepAngle * i / double(steps));
        double x1 = 78 * qCos(angle);
        double y1 = -78 * qSin(angle);
        double x2 = 85 * qCos(angle);
        double y2 = -85 * qSin(angle);
        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
    }

    // --- Big digital value in center ---
    painter.setPen(Qt::white);
    QFont bigFont = painter.font();
    bigFont.setPointSize(28);
    bigFont.setBold(true);
    painter.setFont(bigFont);
    painter.drawText(QRectF(-60, -20, 120, 40), Qt::AlignCenter, QString::number(m_value));

    // --- Unit below value ---
    QFont smallFont = painter.font();
    smallFont.setPointSize(10);
    smallFont.setBold(false);
    painter.setFont(smallFont);
    painter.setPen(QColor(180, 180, 180));
    painter.drawText(QRectF(-60, 15, 120, 20), Qt::AlignCenter, m_unit);

    // --- Title at top ---
    painter.setPen(QColor(150, 150, 150));
    painter.drawText(QRectF(-60, -65, 120, 20), Qt::AlignCenter, m_title);

    // --- Glass reflection highlight ---
    QLinearGradient glossGradient(0, -100, 0, 0);
    glossGradient.setColorAt(0.0, QColor(255, 255, 255, 25));
    glossGradient.setColorAt(1.0, QColor(255, 255, 255, 0));
    painter.setPen(Qt::NoPen);
    painter.setBrush(glossGradient);
    QPainterPath glossPath;
    glossPath.moveTo(-70, -60);
    glossPath.quadTo(0, -95, 70, -60);
    glossPath.quadTo(0, -75, -70, -60);
    painter.drawPath(glossPath);
}