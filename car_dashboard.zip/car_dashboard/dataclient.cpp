#include "dataclient.h"
#include <QJsonDocument>
#include <QJsonObject>

DataClient::DataClient(QObject *parent) : QObject(parent)
{
    m_socket = new QTcpSocket(this);
    connect(m_socket, &QTcpSocket::readyRead, this, &DataClient::onReadyRead);
    connect(m_socket, &QTcpSocket::connected, this, &DataClient::onConnected);
    connect(m_socket, &QTcpSocket::disconnected, this, &DataClient::onDisconnected);
}

void DataClient::connectToServer(const QString &host, quint16 port)
{
    m_socket->connectToHost(host, port);
}

void DataClient::onConnected()
{
    emit connectionStatusChanged(true);
}

void DataClient::onDisconnected()
{
    emit connectionStatusChanged(false);
}

void DataClient::onReadyRead()
{
    m_buffer += m_socket->readAll();

    while (m_buffer.contains('\n'))
    {
        int idx = m_buffer.indexOf('\n');
        QByteArray line = m_buffer.left(idx);
        m_buffer.remove(0, idx + 1);

        QJsonDocument doc = QJsonDocument::fromJson(line);
        if (!doc.isObject()) continue;

        QJsonObject obj = doc.object();
        int speed = obj.value("speed").toInt();
        int rpm   = obj.value("rpm").toInt();
        int gear  = obj.value("gear").toInt();
        int fuel  = obj.value("fuel").toInt();

        emit dataReceived(speed, rpm, gear, fuel);
    }
}

bool DataClient::parseLine(const QByteArray &line, int &speed, int &rpm, int &gear, int &fuel)
{
    QJsonDocument doc = QJsonDocument::fromJson(line);
    if (!doc.isObject()) {
        return false;
    }

    QJsonObject obj = doc.object();
    speed = obj.value("speed").toInt();
    rpm   = obj.value("rpm").toInt();
    gear  = obj.value("gear").toInt();
    fuel  = obj.value("fuel").toInt();
    return true;
}