#ifndef FUELWIDGET_H
#define FUELWIDGET_H

#include <QWidget>

class FuelWidget : public QWidget
{
    Q_OBJECT
public:
    explicit FuelWidget(QWidget *parent = nullptr);
    void setFuelLevel(int percent);
    int fuelLevel() const
    {
        return m_fuel;
    }

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    int m_fuel = 100;
};

#endif // FUELWIDGET_H