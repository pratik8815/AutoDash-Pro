QT += widgets
QT += core gui network
QT += sql
QT += core gui network sql
CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    databasemanager.cpp \
    dataclient.cpp \
    fuelwidget.cpp \
    gaugewidget.cpp \
    gearwidget.cpp \
    main.cpp \
    mainwindow.cpp \
    simulationlogic.cpp

HEADERS += \
    databasemanager.h \
    dataclient.h \
    fuelwidget.h \
    gaugewidget.h \
    gearwidget.h \
    mainwindow.h \
    simulationlogic.h

FORMS += \
    mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
