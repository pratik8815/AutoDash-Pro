#include "databasemanager.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

DatabaseManager::DatabaseManager()
{
}

DatabaseManager::~DatabaseManager()
{
    if (m_db.isOpen()) {
        m_db.close();
    }
}

bool DatabaseManager::init(const QString &dbPath)
{
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName(dbPath);

    if (!m_db.open()) {
        qWarning() << "Failed to open database:" << m_db.lastError().text();
        return false;
    }

    QSqlQuery query;
    bool ok = query.exec(
        "CREATE TABLE IF NOT EXISTS dashboard_log ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "timestamp TEXT DEFAULT CURRENT_TIMESTAMP, "
        "speed INTEGER, "
        "rpm INTEGER, "
        "gear INTEGER, "
        "fuel INTEGER"
        ")"
        );

    if (!ok) {
        qWarning() << "Failed to create table:" << query.lastError().text();
        return false;
    }

    m_initialized = true;
    return true;
}

void DatabaseManager::logData(int speed, int rpm, int gear, int fuel)
{
    if (!m_initialized) return;

    QSqlQuery query;
    query.prepare(
        "INSERT INTO dashboard_log (speed, rpm, gear, fuel) "
        "VALUES (:speed, :rpm, :gear, :fuel)"
        );
    query.bindValue(":speed", speed);
    query.bindValue(":rpm", rpm);
    query.bindValue(":gear", gear);
    query.bindValue(":fuel", fuel);

    if (!query.exec()) {
        qWarning() << "Failed to insert log:" << query.lastError().text();
    }
}