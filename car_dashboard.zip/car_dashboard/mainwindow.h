#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QLabel>
#include <QMainWindow>
#include <QTimer>
#include <QKeyEvent>
#include <QTime>
#include"dataclient.h"
#include"databasemanager.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void keyPressEvent(QKeyEvent *event) override;

private slots:
    void tickSimulation();
    void updateClock();
    void onNetworkDataReceived(int speed, int rpm, int gear,int fuel);

private:
    Ui::MainWindow *ui;
    QTimer *m_simTimer;
    QTimer *m_clockTimer;

    // Target values (what we're driving toward)
    int m_targetSpeed = 0;
    int m_targetRpm = 800;

    // Displayed values (smoothed/eased toward target)
    double m_displaySpeed = 0;
    double m_displayRpm = 800;

    int m_gear = 0;
    int m_fuel = 100;

    bool m_leftOn = false;
    bool m_rightOn = false;
    bool m_hazardOn = false;
    bool m_blinkState = false;

    QLabel *m_leftIndicator;
    QLabel *m_rightIndicator;
    QLabel *m_warningLabel;
    QLabel *m_clockLabel;
    QLabel *m_odometerLabel;
    QLabel *m_brandLabel;
    bool m_warningBlinkState = false;

    double m_odometerKm = 15663.0;

    int maxSpeedForGear(int gear) const;
    void updateGauges();
    void applyGlow(QWidget *w, QColor color);

    DataClient *m_dataClient;
    bool m_networkMode = true;

    DatabaseManager *m_dbManager;

};
#endif // MAINWINDOW_H