#include "guagewidget.h"
#include <QPainter>
#include <QtMath>

GuageWidget::GuageWidget(QWidget *parent)
    : QWidget(parent)
{
    setMinimumSize(200, 200);
}


void GuageWidget::setRange(int minValue, int maxValue)
{
    m_minValue = minValue;
    m_maxValue = maxValue;
    update();
}
void GuageWidget::setTitle(const QString &title)
{
    m_title = title;
    update();
}
void GuageWidget::setUnit(const QString &unit)
{
    m_unit = unit;
    update();
}
void GuageWidget::setValue(int value)
{
    m_value = qBound(m_minValue, value, m_maxValue);
    update();
}

void GuageWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    int side = qMin(width(), height());
    painter.translate(width() / 2, height() / 2);
    painter.scale(side / 220.0,  side / 200.0);

    painter.setPen(QPen(Qt::white, 4));
    painter.setBrush(QColor(20, 20, 20));
    painter.drawEllipse(QPoint(0, 0), 100, 100);

    int startAngle = 225;
    int sweepAngle = -270;
    int steps  = 10;

    painter.setPen(QPen(Qt::white, 2));
    for (int i = 0; i <= steps; ++i) {
        double angle = qDegreesToRadians(startAngle + sweepAngle * i / double(steps));
        double x1 = 85 * qCos(angle);
        double y1 = -85 * qSin(angle);
        double x2 = 95 * qCos(angle);
        double y2 = -95 * qSin(angle);
        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
    }

    double fraction = (m_maxValue > m_minValue)
                          ? double(m_value - m_minValue) / (m_maxValue - m_minValue)
                          : 0.0;
    double needleAngle = qDegreesToRadians(startAngle + sweepAngle * fraction);

    painter.setPen(QPen(Qt::red, 4));
    double nx = 80 * qCos(needleAngle);
    double ny = -80 * qSin(needleAngle);
    painter.drawLine(QPointF(0, 0), QPointF(nx, ny));

    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::white);
    painter.drawEllipse(QPoint(0, 0), 6, 6);

    painter.setPen(Qt::white);
    QFont font = painter.font();
    font.setPointSize(14);
    font.setBold(true);
    painter.setFont(font);
    painter.drawText(QRectF(-50, 30, 100, 30), Qt::AlignCenter,
                     QString("%1 %2").arg(m_value).arg(m_unit));

    font.setPointSize(10);
    font.setBold(false);
    painter.setFont(font);
    painter.drawText(QRectF(-50, -60, 100, 20), Qt::AlignCenter, m_title);

}