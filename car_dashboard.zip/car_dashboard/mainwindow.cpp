#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGraphicsDropShadowEffect>
#include "dataclient.h"
#include "databasemanager.h"
#include <QDebug>



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->rpmGauge->setTitle("RPM");
    ui->rpmGauge->setRange(0, 8000);
    ui->rpmGauge->setUnit("rpm");

    ui->speedGauge->setTitle("SPEED");
    ui->speedGauge->setRange(0, 220);
    ui->speedGauge->setUnit("km/h");

    setFocusPolicy(Qt::StrongFocus);
    setFixedSize(1000, 480);

    // --- Window background: radial dark gradient ---
    setStyleSheet(
        "QMainWindow {"
        "  background: qradialgradient(cx:0.5, cy:0.5, radius:1, "
        "    fx:0.5, fy:0.5, stop:0 #1a1a1a, stop:1 #000000);"
        "}"
        );

    // --- Console panel background for centralwidget ---
    ui->centralwidget->setStyleSheet(
        "QWidget#centralwidget {"
        "  background-color: #0a0a0a;"
        "  border: 2px solid;"
        "  border-color: qlineargradient(x1:0, y1:0, x2:1, y2:1, "
        "    stop:0 #888888, stop:0.5 #444444, stop:1 #888888);"
        "  border-radius: 24px;"
        "}"
        );

    // --- Turn signal indicators ---
    m_leftIndicator = new QLabel("◀", this);
    m_leftIndicator->setStyleSheet("QLabel { color: gray; font-size: 32px; }");
    m_leftIndicator->setAlignment(Qt::AlignCenter);

    m_rightIndicator = new QLabel("▶", this);
    m_rightIndicator->setStyleSheet("QLabel { color: gray; font-size: 32px; }");
    m_rightIndicator->setAlignment(Qt::AlignCenter);

    // --- Warning banner ---
    m_warningLabel = new QLabel("", this);
    m_warningLabel->setAlignment(Qt::AlignCenter);
    m_warningLabel->setStyleSheet("QLabel { background: transparent; }");

    // --- Clock ---
    m_clockLabel = new QLabel(this);
    m_clockLabel->setStyleSheet("QLabel { color: #999999; font-size: 14px; letter-spacing: 1px; }");
    m_clockLabel->setAlignment(Qt::AlignCenter);

    // --- Odometer ---
    m_odometerLabel = new QLabel(this);
    m_odometerLabel->setStyleSheet("QLabel { color: #777777; font-size: 12px; letter-spacing: 1px; }");
    m_odometerLabel->setAlignment(Qt::AlignCenter);
    m_odometerLabel->setText(QString("ODO %1 km").arg(m_odometerKm, 0, 'f', 1));

    // --- Branding ---
    m_brandLabel = new QLabel("DIGITAL INSTRUMENT CLUSTER", this);
    m_brandLabel->setStyleSheet("QLabel { color: #555555; font-size: 10px; letter-spacing: 4px; }");
    m_brandLabel->setAlignment(Qt::AlignCenter);

    // --- Layout placement ---
    ui->gridLayout->addWidget(m_leftIndicator, 0, 0, Qt::AlignRight | Qt::AlignTop);
    ui->gridLayout->addWidget(m_rightIndicator, 0, 2, Qt::AlignLeft | Qt::AlignTop);
    ui->gridLayout->addWidget(m_warningLabel, 2, 0, 1, 3);
    ui->gridLayout->addWidget(m_clockLabel, 3, 0, 1, 3);
    ui->gridLayout->addWidget(m_odometerLabel, 4, 0, 1, 3);
    ui->gridLayout->addWidget(m_brandLabel, 5, 0, 1, 3);

    // --- Glow effects on gauges ---
    applyGlow(ui->rpmGauge, QColor(0, 200, 210, 130));
    applyGlow(ui->speedGauge, QColor(0, 200, 210, 130));
    applyGlow(ui->gearWidget, QColor(255, 255, 255, 60));
    applyGlow(ui->fuelWidget, QColor(0, 200, 120, 90));

    // --- Clock ticking every second ---
    m_clockTimer = new QTimer(this);
    connect(m_clockTimer, &QTimer::timeout, this, &MainWindow::updateClock);
    m_clockTimer->start(1000);
    updateClock();

    // --- Simulation tick (smoothing/physics) every 50ms for fluid animation ---
    m_simTimer = new QTimer(this);
    connect(m_simTimer, &QTimer::timeout, this, &MainWindow::tickSimulation);
    m_simTimer->start(50);

    updateGauges();

    // --- Boot sweep animation: needles sweep to max then settle at 0 ---
    QTimer::singleShot(150, this, [this]() {
        ui->rpmGauge->setValue(8000);
        ui->speedGauge->setValue(220);
    });
    QTimer::singleShot(900, this, [this]() {
        ui->rpmGauge->setValue(qRound(m_displayRpm));
        ui->speedGauge->setValue(qRound(m_displaySpeed));
    });

    m_dataClient = new DataClient(this);
    connect(m_dataClient, &DataClient::dataReceived, this ,&MainWindow::onNetworkDataReceived);
    connect(m_dataClient, &DataClient::connectionStatusChanged, this, [this](bool connected){
        if (connected) {
            m_brandLabel->setText("CONNECTED TO SERVER");
            m_brandLabel->setStyleSheet("QLabel { color: #00c060; font-size: 10px; letter-spacing: 4px; }");
        } else {
            m_brandLabel->setText("DISCONNECTED — SIMULATION MODE");
            m_brandLabel->setStyleSheet("QLabel { color: #cc4444; font-size: 10px; letter-spacing: 4px; }");
        }
    });

    m_dataClient->connectToServer("127.0.0.1", 5555);

    m_dbManager = new DatabaseManager();
    if(m_dbManager->init("dashboard_data.db"))
    {
        qDebug()<< "Database initialized succefully";
    }
    else
    {
        qDebug() << "Database initialization failed";
    }
}

MainWindow::~MainWindow()
{
    delete m_dbManager;
    delete ui;
}

void MainWindow::applyGlow(QWidget *w, QColor color)
{
    auto *effect = new QGraphicsDropShadowEffect(w);
    effect->setBlurRadius(30);
    effect->setColor(color);
    effect->setOffset(0, 0);
    w->setGraphicsEffect(effect);
}

void MainWindow::updateClock()
{
    m_clockLabel->setText(QTime::currentTime().toString("hh:mm:ss AP"));
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_Left:
        m_leftOn = !m_leftOn;
        if (m_leftOn) m_rightOn = false;
        m_hazardOn = false;
        break;

    case Qt::Key_Right:
        m_rightOn = !m_rightOn;
        if (m_rightOn) m_leftOn = false;
        m_hazardOn = false;
        break;

    case Qt::Key_H:
        m_hazardOn = !m_hazardOn;
        m_leftOn = false;
        m_rightOn = false;
        break;

    default:
        QMainWindow::keyPressEvent(event);
        break;
    }
    // int limit = maxSpeedForGear(m_gear);

    // switch (event->key()) {
    // case Qt::Key_Up:
    //     m_targetSpeed = qMin(limit, m_targetSpeed + 8);
    //     break;

    // case Qt::Key_Down:
    //     m_targetSpeed = qMax(0, m_targetSpeed - 10);
    //     break;
    // case Qt::Key_1:
    //     m_gear = 1;
    //     m_targetSpeed = qMin(m_targetSpeed, maxSpeedForGear(1));
    //     break;
    // case Qt::Key_2:
    //     m_gear = 2;
    //     m_targetSpeed = qMin(m_targetSpeed, maxSpeedForGear(2));
    //     break;
    // case Qt::Key_3:
    //     m_gear = 3;
    //     m_targetSpeed = qMin(m_targetSpeed, maxSpeedForGear(3));
    //     break;
    // case Qt::Key_4:
    //     m_gear = 4;
    //     m_targetSpeed = qMin(m_targetSpeed, maxSpeedForGear(4));
    //     break;
    // case Qt::Key_5:
    //     m_gear = 5;
    //     m_targetSpeed = qMin(m_targetSpeed, maxSpeedForGear(5));
    //     break;
    // case Qt::Key_N: m_gear = 0; break;
    // case Qt::Key_R:
    //     m_gear = -1;
    //     m_targetSpeed = qMin(m_targetSpeed, maxSpeedForGear(-1));
    //     break;

    // case Qt::Key_Left:
    //     m_leftOn = !m_leftOn;
    //     if (m_leftOn) m_rightOn = false;
    //     m_hazardOn = false;
    //     break;

    // case Qt::Key_Right:
    //     m_rightOn = !m_rightOn;
    //     if (m_rightOn) m_leftOn = false;
    //     m_hazardOn = false;
    //     break;

    // case Qt::Key_H:
    //     m_hazardOn = !m_hazardOn;
    //     m_leftOn = false;
    //     m_rightOn = false;
    //     break;

    // default:
    //     QMainWindow::keyPressEvent(event);
    //     break;
    // }

}

int MainWindow::maxSpeedForGear(int gear) const
{
    switch (gear) {
    case -1: return 20;
    case 0:  return 0;
    case 1:  return 32;
    case 2:  return 54;
    case 3:  return 80;
    case 4:  return 120;
    case 5:  return 220;
    default: return 0;
    }
}
void MainWindow::tickSimulation()
{
    // --- Gentle coast-down (engine braking) when in a forward gear ---
    // if (m_gear > 0) {
    //     m_targetSpeed = qMax(0, m_targetSpeed - 1);
    // }

    // --- Compute target RPM from target speed + gear ---
    if (m_gear == 0)
    {
        m_targetRpm = 800;
    }
    else if (m_gear == -1)
    {
        m_targetRpm = 800 + m_targetSpeed * 60;
    }
    else
    {
        int gearFactor = 6 - m_gear;
        m_targetRpm = 800 + m_targetSpeed * gearFactor * 25;
    }
    m_targetRpm = qBound(800, m_targetRpm, 8000);

    // --- Smoothly ease displayed values toward targets ---
    double speedEase = 0.12;
    double rpmEase = 0.18;

    m_displaySpeed += (m_targetSpeed - m_displaySpeed) * speedEase;
    m_displayRpm += (m_targetRpm - m_displayRpm) * rpmEase;

    if (qAbs(m_targetSpeed - m_displaySpeed) < 0.3) m_displaySpeed = m_targetSpeed;
    if (qAbs(m_targetRpm - m_displayRpm) < 0.3) m_displayRpm = m_targetRpm;

    // --- Odometer accumulates distance based on current speed ---
    m_odometerKm += m_displaySpeed / 72000.0;
    m_odometerLabel->setText(QString("ODO %1 km").arg(m_odometerKm, 0, 'f', 1));

    // --- Fuel drain ---
    if (m_displaySpeed > 0 && m_fuel > 0) {
        static int fuelTickCounter = 0;
        fuelTickCounter++;
        if (fuelTickCounter >= 100) {
            m_fuel = qMax(0, m_fuel - 1);
            fuelTickCounter = 0;
        }
    }

    // --- Blinkers ---
    static int blinkCounter = 0;
    blinkCounter++;
    if (blinkCounter >= 6) {
        m_blinkState = !m_blinkState;
        blinkCounter = 0;
    }

    bool blinkLeftOn = (m_leftOn || m_hazardOn) && m_blinkState;
    bool blinkRightOn = (m_rightOn || m_hazardOn) && m_blinkState;

    m_leftIndicator->setStyleSheet(blinkLeftOn
                                       ? "QLabel { color: #00e000; font-size: 32px; }"
                                       : "QLabel { color: #303030; font-size: 32px; }");

    m_rightIndicator->setStyleSheet(blinkRightOn
                                        ? "QLabel { color: #00e000; font-size: 32px; }"
                                        : "QLabel { color: #303030; font-size: 32px; }");

    // --- Warnings ---
    bool rpmDanger = m_displayRpm >= 6500;
    bool speedDanger = (m_gear > 0) && (m_displaySpeed >= maxSpeedForGear(m_gear) - 5);

    static int warnCounter = 0;
    warnCounter++;
    if (warnCounter >= 6) {
        m_warningBlinkState = !m_warningBlinkState;
        warnCounter = 0;
    }

    if (rpmDanger) {
        if (m_warningBlinkState) {
            m_warningLabel->setText("⚠ REDLINE — SHIFT UP");
            m_warningLabel->setStyleSheet(
                "QLabel { color: white; background-color: #cc2222; "
                "font-size: 18px; font-weight: bold; border-radius: 6px; padding: 6px; }");
        } else {
            m_warningLabel->setText("");
            m_warningLabel->setStyleSheet("QLabel { background: transparent; }");
        }
    } else if (speedDanger) {
        if (m_warningBlinkState) {
            m_warningLabel->setText("⚠ NEAR GEAR LIMIT");
            m_warningLabel->setStyleSheet(
                "QLabel { color: black; background-color: #e0a800; "
                "font-size: 16px; font-weight: bold; border-radius: 6px; padding: 6px; }");
        } else {
            m_warningLabel->setText("");
            m_warningLabel->setStyleSheet("QLabel { background: transparent; }");
        }
    } else {
        m_warningLabel->setText("");
        m_warningLabel->setStyleSheet("QLabel { background: transparent; }");
    }

    static int dbLogCounter = 0;
    dbLogCounter++;
    if (dbLogCounter >= 20) { // 20 ticks * 50ms = ~1 second
        m_dbManager->logData(qRound(m_displaySpeed), qRound(m_displayRpm), m_gear, m_fuel);
        dbLogCounter = 0;
    }

    updateGauges();
}
void MainWindow::onNetworkDataReceived(int speed,int rpm, int gear,int fuel)
{
    Q_UNUSED(rpm);
    m_targetSpeed = speed;
    //m_targetRpm = rpm;
    m_gear = gear;
    m_fuel = fuel;
}

void MainWindow::updateGauges()
{
    ui->speedGauge->setValue(qRound(m_displaySpeed));
    ui->rpmGauge->setValue(qRound(m_displayRpm));
    ui->fuelWidget->setFuelLevel(m_fuel);
    ui->gearWidget->setGear(m_gear);
}