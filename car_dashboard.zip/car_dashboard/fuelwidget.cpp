#include "fuelwidget.h"
#include <QPainter>

FuelWidget::FuelWidget(QWidget *parent) : QWidget(parent)
{
    setMinimumHeight(60);
}

void FuelWidget::setFuelLevel(int percent)
{
    m_fuel = qBound(0, percent, 100);
    update();
}

void FuelWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    int segments = 10;
    int gap = 4;
    QRect area = rect().adjusted(20, 5, -20, -20);
    int segWidth = (area.width() - gap * (segments - 1)) / segments;

    int litSegments = qRound((m_fuel / 100.0) * segments);

    for (int i = 0; i < segments; ++i) {
        QRect seg(area.left() + i * (segWidth + gap), area.top(), segWidth, area.height());

        QColor color;
        if (i < litSegments) {
            if (m_fuel < 15) color = QColor(220, 50, 50);
            else if (i >= segments - 2) color = QColor(0, 200, 120);
            else color = QColor(0, 180, 210);
        } else {
            color = QColor(40, 40, 40);
        }

        painter.setPen(QPen(QColor(70, 70, 70), 1));
        painter.setBrush(color);
        painter.drawRoundedRect(seg, 3, 3);
    }

    painter.setPen(QColor(160, 160, 160));
    QFont font = painter.font();
    font.setPointSize(10);
    font.setBold(true);
    painter.setFont(font);
    painter.drawText(QRect(0, area.top(), 20, area.height()), Qt::AlignCenter, "E");
    painter.drawText(QRect(width() - 20, area.top(), 20, area.height()), Qt::AlignCenter, "F");

    painter.setPen(Qt::white);
    painter.drawText(rect().adjusted(0, area.height() + 10, 0, 0),
                     Qt::AlignHCenter | Qt::AlignTop, QString("FUEL %1%").arg(m_fuel));
}