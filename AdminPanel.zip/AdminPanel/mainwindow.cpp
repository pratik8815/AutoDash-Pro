#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QJsonObject>
#include <QJsonDocument>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_server = new QTcpServer(this);
    connect(m_server, &QTcpServer::newConnection, this, &MainWindow::onNewConnection);

    connect(ui->startServerButton, &QPushButton::clicked, this, &MainWindow::onStartServerClicked);

    connect(ui->speedSlider, &QSlider::valueChanged, this, &MainWindow::onValuesChanged);
    //connect(ui->rpmSlider, &QSlider::valueChanged, this, &MainWindow::onValuesChanged);
    connect(ui->gearSpinBox, QOverload<int>::of(&QSpinBox::valueChanged), this, &MainWindow::onValuesChanged);
    connect(ui->fuelSlider, &QSlider::valueChanged, this, &MainWindow::onValuesChanged);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onStartServerClicked()
{
    if (m_server->isListening())
    {
        ui->statusLabel->setText("Server is already running");
        return;
    }

    if (m_server->listen(QHostAddress::Any, 5555))
    {
        ui->statusLabel->setText("Server running on port 5555");
    }
    else
    {
        ui->statusLabel->setText("Failed to start server: " + m_server->errorString());
    }
}

void MainWindow::onNewConnection()
{
    QTcpSocket *client = m_server->nextPendingConnection();
    m_clients.append(client);

    connect(client, &QTcpSocket::disconnected, this, &MainWindow::onClientDisconnected);

    ui->statusLabel->setText(QString("Client connected. Total clients: %1").arg(m_clients.size()));

    broadcastData();
}

void MainWindow::onClientDisconnected()
{
    QTcpSocket *client = qobject_cast<QTcpSocket*>(sender());
    if (client)
    {
        m_clients.removeAll(client);
        client->deleteLater();
    }
    ui->statusLabel->setText(QString("Client disconnected. Total clients: %1").arg(m_clients.size()));
}

void MainWindow::onValuesChanged()
{
    broadcastData();
}

void MainWindow::broadcastData()
{
    QJsonObject obj;
    obj["speed"] = ui->speedSlider->value();
    //obj["rpm"]   = ui->rpmSlider->value();
    obj["gear"]  = ui->gearSpinBox->value();
    obj["fuel"]  = ui->fuelSlider->value();

    QJsonDocument doc(obj);
    QByteArray payload = doc.toJson(QJsonDocument::Compact) + "\n";

    for (QTcpSocket *client : m_clients)
    {
        if (client->state() == QAbstractSocket::ConnectedState)
        {
            client->write(payload);
        }
    }
}
